// Instancia centralizada de Axios + interceptores de seguridad.
// Esta capa NO toca el DOM: la redirección al login se delega en un callback
// que registra main.js (inversión de dependencias).
import axios from 'https://cdn.jsdelivr.net/npm/axios@1.7.9/+esm';

const TOKEN_KEY = 'token';

// --- Gestión del token (sessionStorage tiene prioridad sobre localStorage) ---
export const obtenerToken = () =>
  sessionStorage.getItem(TOKEN_KEY) ?? localStorage.getItem(TOKEN_KEY);

export function borrarToken() {
  sessionStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(TOKEN_KEY);
}

// --- Instancia única: nadie repite URLs ni cabeceras a mano ---
export const api = axios.create({
  baseURL: 'http://localhost:3000',
  timeout: 5000
});

// Interceptor de petición: inyecta Authorization: Bearer <token> en TODAS las llamadas
api.interceptors.request.use((config) => {
  const token = obtenerToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Callback que se ejecuta cuando la sesión caduca (lo define main.js)
let alSesionCaducada = () => {};
export function registrarSesionCaducada(callback) {
  alSesionCaducada = callback;
}

// Interceptor de respuesta: 401 => borrar token y avisar para ir a login.html
api.interceptors.response.use(
  (respuesta) => respuesta,
  (error) => {
    if (error.response?.status === 401) {
      borrarToken();
      alSesionCaducada();
    }
    return Promise.reject(error);
  }
);

// --- Utilidades de errores ---
export const esCancelacion = axios.isCancel;

export function mensajeDeError(error) {
  if (error.code === 'ECONNABORTED') return 'Tiempo de espera agotado (5 s). El servidor no responde.';
  if (!error.response) return 'No hay conexión con el servidor. ¿Está json-server arrancado?';
  return `Error HTTP ${error.response.status} al comunicar con el servidor.`;
}
