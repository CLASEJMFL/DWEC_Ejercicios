// Capa de red: solo Axios, cero DOM.
import { api } from './api.js';

const RECURSO = '/incidencias';

// Elimina parámetros vacíos para que la URL quede limpia (?estado=abierta y no ?q=&estado=abierta)
const limpiarParams = (params) =>
  Object.fromEntries(Object.entries(params).filter(([, valor]) => valor !== '' && valor != null));

export const IncidenciasService = {
  // GET filtrado: { q, estado, categoria } viajan como `params` de Axios
  async listar(filtros = {}, signal) {
    const { data } = await api.get(RECURSO, { params: limpiarParams(filtros), signal });
    return data;
  },

  // GET sin filtros (para las métricas globales)
  async listarTodas(signal) {
    const { data } = await api.get(RECURSO, { signal });
    return data;
  },

  // Segundo endpoint opcional: estado del sistema
  async obtenerEstadoSistema(signal) {
    const { data } = await api.get('/sistema', { signal });
    return data;
  },

  // POST (json-server espera JSON; en un backend real se enviaría el FormData directo)
  async crear(formData) {
    const datos = {
      titulo: formData.get('titulo'),
      categoria: formData.get('categoria'),
      estado: 'abierta',
      prioridad: 'Media',
      destacada: false,
      adjunto: formData.get('archivo')?.name || null
    };
    const { data } = await api.post(RECURSO, datos);
    return data;
  },

  // PATCH genérico: estado, prioridad o destacada
  async actualizar(id, cambios) {
    const { data } = await api.patch(`${RECURSO}/${id}`, cambios);
    return data;
  },

  cerrar(id) {
    return this.actualizar(id, { estado: 'cerrada' });
  },

  async eliminar(id) {
    await api.delete(`${RECURSO}/${id}`);
    return true;
  }
};
