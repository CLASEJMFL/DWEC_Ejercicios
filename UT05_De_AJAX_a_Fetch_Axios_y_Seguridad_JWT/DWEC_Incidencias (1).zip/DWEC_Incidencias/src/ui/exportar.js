// Exportación local de informes con Blob (CSV o JSON).
const COLUMNAS = ['id', 'titulo', 'categoria', 'estado', 'prioridad', 'destacada', 'adjunto'];

// Escapa una celda CSV (comillas, separadores, saltos) y neutraliza fórmulas de Excel (=, +, -, @)
function celdaCSV(valor) {
  let texto = String(valor ?? '');
  if (/^[=+\-@]/.test(texto)) texto = `'${texto}`;
  return /[";\n\r]/.test(texto) ? `"${texto.replace(/"/g, '""')}"` : texto;
}

function aCSV(lista) {
  const filas = lista.map((inc) => COLUMNAS.map((c) => celdaCSV(inc[c])).join(';'));
  return [COLUMNAS.join(';'), ...filas].join('\r\n');
}

export function exportarIncidencias(lista, formato = 'csv') {
  const esCsv = formato === 'csv';
  // BOM (\ufeff) + ';' para que Excel en español abra bien tildes y columnas
  const contenido = esCsv ? `\ufeff${aCSV(lista)}` : JSON.stringify(lista, null, 2);

  const blob = new Blob([contenido], {
    type: esCsv ? 'text/csv;charset=utf-8' : 'application/json'
  });
  const url = URL.createObjectURL(blob);

  const enlace = document.createElement('a');
  enlace.href = url;
  enlace.download = `informe-incidencias-${new Date().toISOString().slice(0, 10)}.${esCsv ? 'csv' : 'json'}`;
  document.body.append(enlace);
  enlace.click();
  enlace.remove();

  // Liberamos la memoria del Blob una vez iniciada la descarga
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
