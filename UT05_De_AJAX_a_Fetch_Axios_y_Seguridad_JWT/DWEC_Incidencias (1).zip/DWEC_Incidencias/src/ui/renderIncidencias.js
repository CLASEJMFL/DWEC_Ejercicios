// Capa de vista: solo HTML/DOM, cero red.
const PRIORIDADES = ['Baja', 'Media', 'Alta'];

// Evita inyección de HTML (XSS) al pintar texto que viene del servidor o del usuario
export function escaparHtml(texto) {
  const mapa = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  return String(texto ?? '').replace(/[&<>"']/g, (c) => mapa[c]);
}

// ---------- Estado LOADING (skeletons) ----------
export function pintarLoading(contenedor) {
  contenedor.setAttribute('aria-busy', 'true');
  contenedor.innerHTML = Array.from({ length: 6 }, () => `
    <article class="card skeleton" aria-hidden="true">
      <div class="sk sk-badge"></div>
      <div class="sk sk-titulo"></div>
      <div class="sk sk-linea"></div>
      <div class="sk sk-linea corta"></div>
    </article>`).join('');
}

// ---------- Estado ERROR (con reintento) ----------
export function pintarError(contenedor, mensaje) {
  contenedor.removeAttribute('aria-busy');
  contenedor.innerHTML = `
    <div class="estado-msg error" role="alert">
      ❌ ${escaparHtml(mensaje)}<br><br>
      <button data-accion="reintentar">🔄 Reintentar</button>
    </div>`;
}

// ---------- Estado EMPTY ----------
export function pintarVacio(contenedor, hayFiltros) {
  contenedor.removeAttribute('aria-busy');
  contenedor.innerHTML = `
    <div class="estado-msg">
      📭 ${hayFiltros ? 'Ningún resultado coincide con el filtro o la búsqueda.' : 'Sin incidencias registradas.'}
    </div>`;
}

// ---------- Estado SUCCESS ----------
function tarjetaHTML(inc) {
  const prioridad = PRIORIDADES.includes(inc.prioridad) ? inc.prioridad : 'Media';
  const cerrada = inc.estado === 'cerrada';
  const id = escaparHtml(inc.id);

  return `
    <article class="card ${cerrada ? 'cerrada' : ''} ${inc.destacada ? 'destacada' : ''}" data-id="${id}">
      <div class="card-cabecera">
        <span class="badge">${escaparHtml(inc.categoria)}</span>
        <button class="btn-estrella" data-accion="destacar" data-id="${id}"
                aria-pressed="${Boolean(inc.destacada)}"
                title="${inc.destacada ? 'Quitar destacado' : 'Destacar'}">${inc.destacada ? '★' : '☆'}</button>
      </div>
      <h4>${escaparHtml(inc.titulo)}</h4>
      <p><small>Estado: <strong>${escaparHtml(String(inc.estado).toUpperCase())}</strong></small></p>
      <p><small>Prioridad:
        <select class="prio prio-${prioridad.toLowerCase()}" data-accion="prioridad" data-id="${id}" aria-label="Prioridad">
          ${PRIORIDADES.map((p) => `<option value="${p}" ${p === prioridad ? 'selected' : ''}>${p}</option>`).join('')}
        </select></small></p>
      ${inc.adjunto ? `<p><small>📎 Adjunto: ${escaparHtml(inc.adjunto)}</small></p>` : ''}
      <div class="acciones">
        ${!cerrada ? `<button class="btn-cerrar" data-accion="cerrar" data-id="${id}">✔ Cerrar</button>` : ''}
        <button class="btn-borrar" data-accion="borrar" data-id="${id}" aria-label="Eliminar">🗑️</button>
      </div>
    </article>`;
}

export function pintarIncidencias(contenedor, lista) {
  contenedor.removeAttribute('aria-busy');
  contenedor.innerHTML = lista.map(tarjetaHTML).join('');
}

// Repinta SOLO una tarjeta (Optimistic UI y rollback), conservando el foco del teclado
export function actualizarTarjeta(contenedor, inc) {
  const actual = contenedor.querySelector(`article.card[data-id="${CSS.escape(String(inc.id))}"]`);
  if (!actual) return;

  const accionEnfocada = actual.contains(document.activeElement)
    ? document.activeElement.dataset.accion
    : null;

  const plantilla = document.createElement('template');
  plantilla.innerHTML = tarjetaHTML(inc).trim();
  const nueva = plantilla.content.firstElementChild;
  actual.replaceWith(nueva);

  if (accionEnfocada) nueva.querySelector(`[data-accion="${accionEnfocada}"]`)?.focus();
}

export function quitarTarjeta(contenedor, id) {
  contenedor.querySelector(`article.card[data-id="${CSS.escape(String(id))}"]`)?.remove();
}

// ---------- Panel de métricas ----------
// `datos`: { total, abiertas, cerradas, sistema }  (null = no disponible)
export function pintarMetricas(contenedor, { total, abiertas, cerradas, sistema }) {
  const valor = (n) => (n === null ? '—' : n);
  contenedor.innerHTML = `
    <div class="metrica"><span>Total</span><strong>${valor(total)}</strong></div>
    <div class="metrica"><span>Abiertas</span><strong>${valor(abiertas)}</strong></div>
    <div class="metrica"><span>Cerradas</span><strong>${valor(cerradas)}</strong></div>
    <div class="metrica ${sistema ? 'ok' : 'ko'}">
      <span>Sistema</span>
      <strong>${sistema ? `✅ ${escaparHtml(sistema.estado)}` : '⚠️ No disponible'}</strong>
    </div>`;
}

// ---------- Avisos (toast) ----------
export function mostrarAviso(mensaje, tipo = 'info') {
  let zona = document.querySelector('#avisos');
  if (!zona) {
    zona = document.createElement('div');
    zona.id = 'avisos';
    document.body.append(zona);
  }
  const aviso = document.createElement('div');
  aviso.className = `aviso ${tipo}`;
  aviso.setAttribute('role', tipo === 'error' ? 'alert' : 'status');
  aviso.textContent = mensaje;
  zona.append(aviso);
  setTimeout(() => aviso.remove(), 4500);
}
