import { IncidenciasService } from './services/incidenciasService.js';
import { obtenerToken, borrarToken, registrarSesionCaducada, esCancelacion, mensajeDeError } from './services/api.js';
import {
  pintarIncidencias, pintarLoading, pintarError, pintarVacio,
  actualizarTarjeta, quitarTarjeta, pintarMetricas, mostrarAviso
} from './ui/renderIncidencias.js';
import { exportarIncidencias } from './ui/exportar.js';

// ---------- Guardia de sesión ----------
const irALogin = (motivo = '') => location.replace(`login.html${motivo ? `?motivo=${motivo}` : ''}`);
if (!obtenerToken()) irALogin();
registrarSesionCaducada(() => irALogin('caducada')); // lo invoca el interceptor 401

// ---------- Referencias al DOM ----------
const grid = document.querySelector('#grid');
const form = document.querySelector('#formIncidencia');
const btnCrear = document.querySelector('#btnCrear');
const inputBuscar = document.querySelector('#inputBuscar');
const selEstado = document.querySelector('#filtroEstado');
const selCategoria = document.querySelector('#filtroCategoria');
const selFormato = document.querySelector('#formatoExport');
const btnExportar = document.querySelector('#btnExportar');
const btnSalir = document.querySelector('#btnSalir');
const panelMetricas = document.querySelector('#metricas');

// ---------- Estado de la aplicación (módulo, no global) ----------
let incidencias = [];            // lo que se ve ahora mismo en el grid
let controladorListado = null;   // cancela listados en vuelo
let controladorMetricas = null;  // cancela métricas en vuelo

const leerFiltros = () => ({
  q: inputBuscar.value.trim(),
  estado: selEstado.value,
  categoria: selCategoria.value
});
const hayFiltros = () => Object.values(leerFiltros()).some(Boolean);

function debounce(fn, espera = 350) {
  let temporizador;
  return (...args) => {
    clearTimeout(temporizador);
    temporizador = setTimeout(() => fn(...args), espera);
  };
}

// ---------- Métricas (tolerantes a fallos parciales) ----------
function aplicarMetricas(resTodas, resSistema) {
  const todas = resTodas.status === 'fulfilled' ? resTodas.value : null;
  pintarMetricas(panelMetricas, {
    total: todas ? todas.length : null,
    abiertas: todas ? todas.filter((i) => i.estado === 'abierta').length : null,
    cerradas: todas ? todas.filter((i) => i.estado === 'cerrada').length : null,
    sistema: resSistema.status === 'fulfilled' ? resSistema.value : null
  });
}

async function refrescarMetricas() {
  controladorMetricas?.abort();
  controladorMetricas = new AbortController();
  const { signal } = controladorMetricas;

  const [resTodas, resSistema] = await Promise.allSettled([
    IncidenciasService.listarTodas(signal),
    IncidenciasService.obtenerEstadoSistema(signal)
  ]);
  if (signal.aborted) return;
  aplicarMetricas(resTodas, resSistema);
}

// ---------- Carga principal: 4 estados + concurrencia ----------
async function cargarVista({ conMetricas = true } = {}) {
  controladorListado?.abort();
  controladorListado = new AbortController();
  const { signal } = controladorListado;

  pintarLoading(grid);

  // Listado + métricas EN PARALELO. allSettled: si falla el endpoint secundario,
  // el listado principal se pinta igualmente.
  const tareas = [IncidenciasService.listar(leerFiltros(), signal)];
  if (conMetricas) {
    controladorMetricas?.abort();
    controladorMetricas = new AbortController();
    tareas.push(
      IncidenciasService.listarTodas(controladorMetricas.signal),
      IncidenciasService.obtenerEstadoSistema(controladorMetricas.signal)
    );
  }
  const [resListado, resTodas, resSistema] = await Promise.allSettled(tareas);

  if (signal.aborted) return; // una búsqueda más reciente ha tomado el relevo
  if (conMetricas && !controladorMetricas.signal.aborted) aplicarMetricas(resTodas, resSistema);

  if (resListado.status === 'rejected') {
    if (esCancelacion(resListado.reason)) return;
    incidencias = [];
    pintarError(grid, mensajeDeError(resListado.reason));
    return;
  }

  incidencias = resListado.value;
  if (incidencias.length) pintarIncidencias(grid, incidencias);
  else pintarVacio(grid, hayFiltros());
}

// ---------- Optimistic UI con rollback ----------
const buscarEnEstado = (id) => incidencias.find((i) => String(i.id) === String(id));

async function actualizarOptimista(id, cambios) {
  const inc = buscarEnEstado(id);
  if (!inc) return;

  // 1) Guardamos SOLO los campos que vamos a tocar y pintamos al instante
  const previo = Object.fromEntries(Object.keys(cambios).map((campo) => [campo, inc[campo]]));
  Object.assign(inc, cambios);
  actualizarTarjeta(grid, inc);

  try {
    await IncidenciasService.actualizar(id, cambios);
    if ('estado' in cambios) refrescarMetricas();
  } catch (err) {
    // 2) Rollback: volvemos al estado previo y avisamos
    const actual = buscarEnEstado(id);
    if (actual) {
      Object.assign(actual, previo);
      actualizarTarjeta(grid, actual);
    }
    if (!esCancelacion(err)) {
      mostrarAviso(`No se pudo guardar el cambio. Se ha revertido. (${mensajeDeError(err)})`, 'error');
    }
  }
}

// ---------- Alta ----------
form.addEventListener('submit', async (e) => {
  e.preventDefault();
  btnCrear.disabled = true;
  btnCrear.textContent = 'Guardando...';
  try {
    await IncidenciasService.crear(new FormData(form));
    form.reset();
    mostrarAviso('Incidencia registrada', 'ok');
    await cargarVista();
  } catch (err) {
    mostrarAviso(mensajeDeError(err), 'error');
  } finally {
    btnCrear.disabled = false;
    btnCrear.textContent = 'Registrar';
  }
});

// ---------- Filtros y buscador (Debounce 350 ms + AbortController) ----------
const recargarListado = debounce(() => cargarVista({ conMetricas: false }), 350);
inputBuscar.addEventListener('input', recargarListado);
selEstado.addEventListener('change', () => cargarVista({ conMetricas: false }));
selCategoria.addEventListener('change', () => cargarVista({ conMetricas: false }));

// ---------- Delegación de eventos en el grid (un solo listener por tipo) ----------
grid.addEventListener('click', async (e) => {
  const boton = e.target.closest('button[data-accion]');
  if (!boton) return;
  const { accion, id } = boton.dataset;

  if (accion === 'reintentar') {
    cargarVista();
  } else if (accion === 'cerrar') {
    actualizarOptimista(id, { estado: 'cerrada' });
  } else if (accion === 'destacar') {
    const inc = buscarEnEstado(id);
    if (inc) actualizarOptimista(id, { destacada: !inc.destacada });
  } else if (accion === 'borrar') {
    try {
      await IncidenciasService.eliminar(id);
      incidencias = incidencias.filter((i) => String(i.id) !== String(id));
      quitarTarjeta(grid, id);
      if (!incidencias.length) pintarVacio(grid, hayFiltros());
      refrescarMetricas();
    } catch (err) {
      mostrarAviso(mensajeDeError(err), 'error');
    }
  }
});

grid.addEventListener('change', (e) => {
  const selector = e.target.closest('select[data-accion="prioridad"]');
  if (selector) actualizarOptimista(selector.dataset.id, { prioridad: selector.value });
});

// ---------- Exportar informe (Blob) ----------
btnExportar.addEventListener('click', () => {
  if (!incidencias.length) {
    mostrarAviso('No hay incidencias que exportar con el filtro actual.', 'error');
    return;
  }
  exportarIncidencias(incidencias, selFormato.value);
});

// ---------- Cerrar sesión ----------
btnSalir.addEventListener('click', () => {
  borrarToken();
  irALogin();
});

// ---------- Arranque ----------
if (obtenerToken()) cargarVista();
